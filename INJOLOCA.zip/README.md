INJOLOCA - Extensão do Google Chrome para auxiliar o preenchimento das apostas no site de Loterias Online da Caixa

Como usar? Veja o vídeo https://youtu.be/CbIE_54CLww
